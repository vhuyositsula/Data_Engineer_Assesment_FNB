USE [TransformationDB]
GO

/****** Object:  Table [dbo].[HighLowElevCities]    Script Date: 2024/03/03 23:27:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[HighLowElevCities](
	[countryName] [varchar](100) NULL,
	[cityName] [varchar](100) NULL,
	[highestElevatedCity] [int] NULL,
	[lowestElevatedCity] [int] NULL
) ON [PRIMARY]
GO

