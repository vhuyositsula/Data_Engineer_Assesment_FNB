USE [StagingDB]
GO

/****** Object:  Table [dbo].[airports]    Script Date: 2024/03/03 23:14:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[airports](
	[id] [int] NOT NULL,
	[ident] [varchar](500) NOT NULL,
	[type] [varchar](500) NULL,
	[name] [varchar](500) NULL,
	[latitude_deg] [varchar](500) NULL,
	[longitude_deg] [varchar](500) NULL,
	[elevation_ft] [varchar](500) NULL,
	[continent] [varchar](500) NULL,
	[iso_country] [varchar](50) NULL,
	[iso_region] [varchar](500) NULL,
	[municipality] [varchar](500) NULL,
	[scheduled_service] [varchar](500) NULL,
	[gps_code] [varchar](500) NULL,
	[iata_code] [varchar](500) NULL,
	[local_code] [varchar](500) NULL,
	[home_link] [varchar](500) NULL,
	[wikipedia_link] [varchar](500) NULL,
	[keywords] [varchar](500) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[ident] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

