USE [TransformationDB]
GO

/****** Object:  Table [dbo].[ElevationStatsByCountry]    Script Date: 2024/03/03 23:22:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ElevationStatsByCountry](
	[countryName] [varchar](100) NULL,
	[MaxElevation] [int] NULL,
	[AvgElevation] [int] NULL,
	[MinElevation] [int] NULL
) ON [PRIMARY]
GO

