USE [StagingDB]
GO

/****** Object:  Table [dbo].[countries]    Script Date: 2024/03/03 23:16:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[countries](
	[id] [int] NOT NULL,
	[code] [varchar](50) NOT NULL,
	[name] [varchar](500) NULL,
	[continent] [varchar](500) NULL,
	[wikipedia_link] [varchar](500) NULL,
	[keywords] [varchar](500) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

