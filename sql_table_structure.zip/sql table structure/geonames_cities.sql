USE [StagingDB]
GO

/****** Object:  Table [dbo].[geonames_cities]    Script Date: 2024/03/03 23:18:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[geonames_cities](
	[geonameid] [int] NULL,
	[name] [varchar](200) NULL,
	[asciiname] [varchar](200) NULL,
	[alternatenames] [varchar](max) NULL,
	[latitude] [real] NULL,
	[longitude] [real] NULL,
	[feature_class] [char](1) NULL,
	[feature_code] [varchar](10) NULL,
	[country_code] [varchar](50) NULL,
	[cc2] [varchar](200) NULL,
	[admin1_code] [varchar](20) NULL,
	[admin2_code] [varchar](80) NULL,
	[admin3_code] [varchar](20) NULL,
	[admin4_code] [varchar](20) NULL,
	[population] [bigint] NULL,
	[elevation] [int] NULL,
	[dem] [int] NULL,
	[timezone] [varchar](40) NULL,
	[modification_date] [datetime] NULL,
	[filename] [varchar](20) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

