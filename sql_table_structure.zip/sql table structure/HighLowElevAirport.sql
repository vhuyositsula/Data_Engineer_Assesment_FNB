USE [TransformationDB]
GO

/****** Object:  Table [dbo].[HighLowElevAirport]    Script Date: 2024/03/03 23:25:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[HighLowElevAirport](
	[countryName] [varchar](50) NULL,
	[airportType] [varchar](50) NULL,
	[highestElevatedCity] [int] NULL,
	[lowestElevatedCity] [int] NULL
) ON [PRIMARY]
GO

