USE [TransformationDB]
GO

/****** Object:  Table [dbo].[AirportCountByCountry]    Script Date: 2024/03/03 23:19:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AirportCountByCountry](
	[CountryName] [varchar](500) NULL,
	[Continent] [varchar](50) NULL,
	[AirportCount] [int] NULL,
	[AirfieldCount] [int] NULL,
	[HeliportCount] [int] NULL
) ON [PRIMARY]
GO

