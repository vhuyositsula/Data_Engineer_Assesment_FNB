USE [TransformationDB]
GO

/****** Object:  Table [dbo].[HighLowElevAirport]    Script Date: 2024/03/04 01:05:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[HighLowElevAirport](
	[countryName] [varchar](50) NULL,
	[airportType] [varchar](50) NULL,
	[highestElevatedAirport] [int] NULL,
	[lowestElevatedAirport] [int] NULL
) ON [PRIMARY]
GO

