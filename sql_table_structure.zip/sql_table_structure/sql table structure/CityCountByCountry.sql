USE [TransformationDB]
GO

/****** Object:  Table [dbo].[CityCountByCountry]    Script Date: 2024/03/03 23:21:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CityCountByCountry](
	[countryName] [varchar](100) NULL,
	[cityCount] [int] NULL
) ON [PRIMARY]
GO

