USE [StagingDB]
GO

/****** Object:  Table [dbo].[CountryInfo]    Script Date: 2024/03/03 23:17:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CountryInfo](
	[countryCode] [varchar](50) NOT NULL,
	[countryName] [varchar](500) NULL,
	[isoNumeric] [varchar](500) NULL,
	[isoAlpha3] [varchar](500) NULL,
	[fipsCode] [varchar](500) NULL,
	[continent] [varchar](500) NULL,
	[continentName] [varchar](500) NULL,
	[capital] [varchar](500) NULL,
	[areaInSqKm] [varchar](500) NULL,
	[population] [varchar](500) NULL,
	[currencyCode] [varchar](500) NULL,
	[languages] [varchar](500) NULL,
	[geonameId] [varchar](500) NULL,
	[west] [varchar](500) NULL,
	[north] [varchar](500) NULL,
	[east] [varchar](500) NULL,
	[south] [varchar](500) NULL,
	[postalCodeFormat] [varchar](500) NULL,
PRIMARY KEY CLUSTERED 
(
	[countryCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

