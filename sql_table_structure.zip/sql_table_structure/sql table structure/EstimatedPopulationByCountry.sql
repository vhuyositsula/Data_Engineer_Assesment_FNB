USE [TransformationDB]
GO

/****** Object:  Table [dbo].[EstimatedPopulationByCountry]    Script Date: 2024/03/03 23:24:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[EstimatedPopulationByCountry](
	[countryCode] [varchar](50) NULL,
	[countryName] [varchar](100) NULL,
	[population] [varchar](100) NULL
) ON [PRIMARY]
GO

