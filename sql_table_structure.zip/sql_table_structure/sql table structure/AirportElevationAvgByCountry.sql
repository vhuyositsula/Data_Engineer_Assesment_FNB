USE [TransformationDB]
GO

/****** Object:  Table [dbo].[AirportElevationAvgByCountry]    Script Date: 2024/03/03 23:20:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AirportElevationAvgByCountry](
	[country_name] [varchar](100) NULL,
	[type] [varchar](20) NULL,
	[elevation] [int] NULL
) ON [PRIMARY]
GO

